import React from 'react'

const Top = () => {
  return (
    <div>
      <img src='https://i.namu.wiki/i/g4GJv2QCTuvr4oAbDvhPKMRzQlxObAnXRh-8bOJlV-q_L4X4eWHvQdmIsnhSl3qgd0hh96JZdbprvVzUkC8rAq7qKah_E-8YQk5lwBSza_ZeTv8wYP7Lj5P-eXJ7jvRqBJnck92hYW0952riKcVwOg.svg'/>
    </div>
  )
}

export default Top
