import React from 'react'

const Bottom = () => {
  return (
    <div className='text-center'>
      <hr/>
      <h3>Copyright 2024. 함범진 All rights reserved</h3>
    </div>
  )
}

export default Bottom
